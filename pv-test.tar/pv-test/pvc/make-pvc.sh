#!/bin/bash

for i in {001..010}
do
cat > ./pvc-$i.yaml << EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: g600-pvc-$i
spec:
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 1Gi
  storageClassName: g600-flex-sc
EOF
done

